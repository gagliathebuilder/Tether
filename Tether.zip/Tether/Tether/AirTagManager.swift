import Foundation
import CoreBluetooth

class AirTagManager: NSObject, ObservableObject {
    @Published var pairedAirTags: [UUID] = []
    private var centralManager: CBCentralManager!
    
    override init() {
        super.init()
        centralManager = CBCentralManager(delegate: self, queue: nil)
    }
    
    func startScanning() {
        if centralManager.state == .poweredOn {
            centralManager.scanForPeripherals(withServices: nil, options: nil)
        }
    }
    
    func stopScanning() {
        centralManager.stopScan()
    }
    
    func pairAirTag(id: UUID) {
        if !pairedAirTags.contains(id) {
            pairedAirTags.append(id)
        }
    }
}

extension AirTagManager: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            startScanning()
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        // In a real scenario, we would filter for AirTags here
        // For this proof of concept, we'll treat all discovered peripherals as potential AirTags
        DispatchQueue.main.async {
            self.pairAirTag(id: peripheral.identifier)
        }
    }
}
