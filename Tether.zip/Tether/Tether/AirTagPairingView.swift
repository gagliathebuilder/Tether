import SwiftUI

struct AirTagPairingView: View {
    @StateObject private var airTagManager = AirTagManager()
    @State private var isScanning = false
    
    var body: some View {
        VStack {
            Text("AirTag Pairing")
                .font(.title)
                .padding()
            
            if isScanning {
                ProgressView("Scanning for AirTags...")
            } else {
                Button(action: {
                    isScanning = true
                    airTagManager.startScanning()
                }) {
                    Text("Start Scanning")
                }
            }
            
            List(airTagManager.pairedAirTags, id: \.self) { airTag in
                Text("AirTag: \(airTag.uuidString)")
            }
        }
        .onDisappear {
            airTagManager.stopScanning()
        }
    }
}

struct AirTagPairingView_Previews: PreviewProvider {
    static var previews: some View {
        AirTagPairingView()
    }
}
