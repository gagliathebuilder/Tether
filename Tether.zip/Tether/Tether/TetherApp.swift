import SwiftUI

@main
struct TetherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
