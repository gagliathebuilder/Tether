
import Foundation
import SwiftUI

class AuthenticationManager: ObservableObject {
    @Published var isLoggedIn = false
    
    func login(email: String, password: String) {
        // TODO: Implement actual authentication logic
        isLoggedIn = true
    }
    
    func logout() {
        isLoggedIn = false
    }
}

