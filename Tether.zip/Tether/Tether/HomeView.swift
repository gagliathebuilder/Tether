import SwiftUI

struct HomeView: View {
    @EnvironmentObject var authManager: AuthenticationManager
    @State private var showingAirTagPairing = false
    @State private var showingGeoFenceConfig = false
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Welcome to Tether")
                    .font(.title)
                
                Button("Pair AirTag") {
                    showingAirTagPairing = true
                }
                .padding()
                
                Button("Configure Geo-Fences") {
                    showingGeoFenceConfig = true
                }
                .padding()
                
                Button("Logout") {
                    authManager.logout()
                }
                .padding()
            }
            .navigationTitle("Home")
            .sheet(isPresented: $showingAirTagPairing) {
                AirTagPairingView()
            }
            .sheet(isPresented: $showingGeoFenceConfig) {
                GeoFenceConfigurationView()
            }
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
            .environmentObject(AuthenticationManager())
    }
}
