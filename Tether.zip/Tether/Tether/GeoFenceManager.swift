import Foundation
import CoreLocation

struct GeoFence: Identifiable {
    let id = UUID()
    var name: String
    var coordinate: CLLocationCoordinate2D
    var radius: CLLocationDistance
}

class GeoFenceManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var geoFences: [GeoFence] = []
    private let locationManager = CLLocationManager()
    
    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()
    }
    
    func addGeoFence(_ geoFence: GeoFence) {
        geoFences.append(geoFence)
        let region = CLCircularRegion(center: geoFence.coordinate, radius: geoFence.radius, identifier: geoFence.id.uuidString)
        region.notifyOnEntry = true
        region.notifyOnExit = true
        locationManager.startMonitoring(for: region)
    }
    
    func removeGeoFence(_ geoFence: GeoFence) {
        if let index = geoFences.firstIndex(where: { $0.id == geoFence.id }) {
            geoFences.remove(at: index)
            let region = CLCircularRegion(center: geoFence.coordinate, radius: geoFence.radius, identifier: geoFence.id.uuidString)
            locationManager.stopMonitoring(for: region)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        print("Entered region: \(region.identifier)")
        // Here you would typically send a notification to the user
    }
    
    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        print("Exited region: \(region.identifier)")
        // Here you would typically send a notification to the user
    }
}
