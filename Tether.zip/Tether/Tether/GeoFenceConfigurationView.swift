import SwiftUI
import MapKit

struct GeoFenceConfigurationView: View {
    @StateObject private var geoFenceManager = GeoFenceManager()
    @State private var newGeoFenceName = ""
    @State private var newGeoFenceRadius: Double = 100
    @State private var mapRegion = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194), span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
    @State private var showingAddGeoFence = false
    
    var body: some View {
        VStack {
            Map(coordinateRegion: $mapRegion, annotationItems: geoFenceManager.geoFences) { geoFence in
                MapAnnotation(coordinate: geoFence.coordinate) {
                    Circle()
                        .stroke(Color.red, lineWidth: 2)
                        .frame(width: 44, height: 44)
                }
            }
            .edgesIgnoringSafeArea(.all)
            
            Button("Add Geo-Fence") {
                showingAddGeoFence = true
            }
            .padding()
        }
        .sheet(isPresented: $showingAddGeoFence) {
            AddGeoFenceView(mapRegion: $mapRegion, onSave: { name, radius in
                let newGeoFence = GeoFence(name: name, coordinate: mapRegion.center, radius: radius)
                geoFenceManager.addGeoFence(newGeoFence)
                showingAddGeoFence = false
            })
        }
    }
}

struct AddGeoFenceView: View {
    @Binding var mapRegion: MKCoordinateRegion
    let onSave: (String, CLLocationDistance) -> Void
    @State private var name = ""
    @State private var radius: Double = 100
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Geo-Fence Details")) {
                    TextField("Name", text: $name)
                    Slider(value: $radius, in: 50...1000, step: 50) {
                        Text("Radius: \(Int(radius)) meters")
                    }
                }
                
                Section {
                    Button("Save") {
                        onSave(name, radius)
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            }
            .navigationTitle("Add Geo-Fence")
        }
    }
}

struct GeoFenceConfigurationView_Previews: PreviewProvider {
    static var previews: some View {
        GeoFenceConfigurationView()
    }
}
